fastload table orders
o_id 1
o_d_id 2
o_w_id 3
o_c_id 4
o_entry_d 5
o_carrier_id 6 NULL if pos 6 = 'NULL'
o_ol_cnt 7
o_all_local 8
infile '/tmp/order.data'
