fastload table warehouse
w_id 1
w_name 2
w_street_1 3
w_street_2 4
w_city 5
w_state 6
w_zip 7
w_tax 8
w_ytd 9
infile '/tmp/warehouse.data'
