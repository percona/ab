fastload table order_line
ol_o_id 1
ol_d_id 2
ol_w_id 3
ol_number 4
ol_i_id 5
ol_supply_w_id 6
ol_delivery_d 7 NULL if pos 7 = 'NULL'
ol_quantity 8
ol_amount 9
ol_dist_info 10
infile '/tmp/order_line.data'
