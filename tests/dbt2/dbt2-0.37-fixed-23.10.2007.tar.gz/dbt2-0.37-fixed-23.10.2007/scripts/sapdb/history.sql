fastload table history
h_c_id 1
h_c_d_id 2
h_c_w_id 3
h_d_id 4
h_w_id 5
h_date 6
h_amount 7
h_data 8
infile '/tmp/history.data'
