fastload table new_order
no_o_id 1
no_d_id 2
no_w_id 3
infile '/tmp/new_order.data'
