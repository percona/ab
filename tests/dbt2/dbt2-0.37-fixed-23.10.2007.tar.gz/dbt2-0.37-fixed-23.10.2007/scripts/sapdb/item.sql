fastload table item
i_id 1
i_im_id 2
i_name 3
i_price 4
i_data 5
infile '/tmp/item.data'
