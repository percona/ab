fastload table district
d_id 1
d_w_id 2
d_name 3
d_street_1 4
d_street_2 5
d_city 6
d_state 7
d_zip 8
d_tax 9
d_ytd 10
d_next_o_id 11
infile '/tmp/district.data'
